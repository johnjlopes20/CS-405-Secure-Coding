// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>
#include <stdexcept> // Include for standard exception types

// CustomException class that extends from std::exception
struct CustomException : public std::exception
{
	// Override the what() method to provide a custom exception message
	virtual const char* what() const throw() override
	{
		return "Test of custom exception message";
	}
};

// Function demonstrating custom application logic that may throw exceptions
bool do_even_more_custom_application_logic()
{
	// TODO: Throw a standard exception
	throw std::bad_exception(); // Throws an exception to simulate an error

	std::cout << "Running Even More Custom Application Logic." << std::endl;

	return true;
}

// Function handling custom application logic with exception handling
void do_custom_application_logic()
{
	std::cout << "Running Custom Application Logic." << std::endl;

	try
	{
		// Call a function that might throw an exception and handle it
		if (do_even_more_custom_application_logic())
		{
			std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
		}
	}
	catch (const std::exception& exception)
	{
		// Handle standard exceptions
		std::cerr << "Caught standard exception: " << exception.what() << std::endl;
	}

	// TODO: Throw a custom exception derived from std::exception
	throw CustomException(); // Throws a custom exception

	std::cout << "Leaving Custom Application Logic." << std::endl;
}

// Function performing division and throwing exceptions for divide-by-zero errors
float divide(float num, float den)
{
	// TODO: Throw an exception to handle divide by zero errors
	if (den == 0)
	{
		// Throw a standard runtime error for divide by zero
		throw std::runtime_error("Divide by zero error");
	}
	return (num / den);
}

// Function demonstrating exception handling specifically for divide errors
void do_division()
{
	float numerator = 10.0f;
	float denominator = 0;

	try
	{
		// Attempt division which may throw an exception
		auto result = divide(numerator, denominator);
		std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
	}
	catch (const std::runtime_error& exception)
	{
		// Handle runtime errors specifically from divide function
		std::cerr << "Caught runtime_error: " << exception.what() << std::endl;
	}
}

// Main function demonstrating overall exception handling
int main()
{
	try
	{
		std::cout << "Exceptions Tests" << std::endl;

		// Call functions that may throw exceptions
		do_division();
		do_custom_application_logic();
	}
	catch (const CustomException& exception)
	{
		// Handle custom exceptions
		std::cerr << "Caught custom exception: " << exception.what() << std::endl;
	}
	catch (const std::exception& exception)
	{
		// Handle all standard exceptions
		std::cerr << "Caught standard exception: " << exception.what() << std::endl;
	}
	catch (...)
	{
		// Catch all other exceptions (unknown)
		std::cerr << "Caught unknown exception." << std::endl;
	}

	return 0;
}

