// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"

// Global test environment setup and teardown
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Define setup actions before running any tests
    void SetUp() override
    {
        // Initialize random seed for generating random test data
        srand(time(nullptr));
    }

    // Define teardown actions after running all tests
    void TearDown() override {}
};

// Test fixture class to manage shared state between tests
class CollectionTest : public ::testing::Test
{
protected:
    // Smart pointer to hold our collection of integers
    std::unique_ptr<std::vector<int>> collection;

    // Setup a new collection before each test
    void SetUp() override
    {
        collection.reset(new std::vector<int>);
    }

    // Clear the collection and reset the pointer after each test
    void TearDown() override
    {
        collection->clear();
        collection.reset(nullptr);
    }

    // Helper function to add random values to the collection
    void add_entries(int count)
    {
        assert(count > 0); // Ensure count is positive
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100); // Add random values between 0 and 99
    }
};

// Test that a collection is not null when created
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection); // Ensure collection pointer is valid
    ASSERT_NE(collection.get(), nullptr); // Ensure the raw pointer is not null
}

// Test that the collection is empty when created
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty()); // Ensure the collection is empty
    ASSERT_EQ(collection->size(), 0); // Ensure the size is 0
}

// Uncomment this test to see a failure in the test explorer
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL(); // This test will always fail
//}

// Test adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    ASSERT_TRUE(collection->empty()); // Ensure the collection is initially empty
    ASSERT_EQ(collection->size(), 0); // Ensure the size is 0

    add_entries(1); // Add one entry to the collection

    ASSERT_FALSE(collection->empty()); // Ensure the collection is no longer empty
    ASSERT_EQ(collection->size(), 1); // Ensure the size is 1
}

// Test adding five values to the collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    ASSERT_TRUE(collection->empty()); // Ensure the collection is initially empty
    ASSERT_EQ(collection->size(), 0); // Ensure the size is 0

    add_entries(5); // Add five entries to the collection

    ASSERT_FALSE(collection->empty()); // Ensure the collection is no longer empty
    ASSERT_EQ(collection->size(), 5); // Ensure the size is 5
}

// Test that max size of the collection is greater than or equal to size for various entry counts
TEST_F(CollectionTest, CheckMaxSize)
{
    ASSERT_TRUE(collection->empty()); // Ensure the collection is initially empty
    ASSERT_EQ(collection->size(), 0); // Ensure the size is 0

    add_entries(11); // Add more than 10 entries

    ASSERT_GE(collection->max_size(), 0); // Max size should be greater than or equal to 0
    ASSERT_GE(collection->max_size(), 1); // Max size should be greater than or equal to 1
    ASSERT_GE(collection->max_size(), 5); // Max size should be greater than or equal to 5
    ASSERT_GE(collection->max_size(), 10); // Max size should be greater than or equal to 10
}

// Test that capacity of the collection is greater than or equal to size for various entry counts
TEST_F(CollectionTest, CheckCapacity)
{
    ASSERT_TRUE(collection->empty()); // Ensure the collection is initially empty
    ASSERT_EQ(collection->size(), 0); // Ensure the size is 0

    ASSERT_GE(collection->capacity(), 0); // Capacity should be greater than or equal to 0

    add_entries(11); // Add more than 10 entries

    ASSERT_GE(collection->capacity(), 1); // Capacity should be greater than or equal to 1
    ASSERT_GE(collection->capacity(), 5); // Capacity should be greater than or equal to 5
    ASSERT_GE(collection->capacity(), 10); // Capacity should be greater than or equal to 10
}

// Test resizing the collection increases its size
TEST_F(CollectionTest, ResizeIsGreater)
{
    add_entries(1); // Add one entry to the collection

    int previousSize = collection->size(); // Save previous size
    collection->resize(10); // Resize the collection to 10

    ASSERT_TRUE(collection->size() > previousSize); // Ensure size has increased
}

// Test resizing the collection decreases its size
TEST_F(CollectionTest, ResizeIsLesser)
{
    add_entries(10); // Add ten entries to the collection

    int previousSize = collection->size(); // Save previous size
    collection->resize(1); // Resize the collection to 1

    ASSERT_TRUE(collection->size() < previousSize); // Ensure size has decreased
}

// Test resizing the collection to zero
TEST_F(CollectionTest, ResizeIsZero)
{
    add_entries(10); // Add ten entries to the collection

    collection->resize(0); // Resize the collection to 0
    ASSERT_EQ(collection->size(), 0); // Ensure size is 0
}

// Test clearing the collection removes all entries
TEST_F(CollectionTest, ClearCollection)
{
    add_entries(10); // Add ten entries to the collection

    collection->clear(); // Clear the collection
    ASSERT_EQ(collection->size(), 0); // Ensure size is 0
}

// Test erase(begin, end) removes all entries from the collection
TEST_F(CollectionTest, EraseCheck)
{
    add_entries(10); // Add ten entries to the collection

    collection->erase(collection->begin(), collection->end()); // Erase all entries
    ASSERT_EQ(collection->size(), 0); // Ensure size is 0
}

// Test that reserve increases the capacity without changing the size
TEST_F(CollectionTest, ReserveIncrease)
{
    add_entries(10); // Add ten entries to the collection

    int prevCapacity = collection->capacity(); // Save previous capacity
    int prevSize = collection->size(); // Save previous size

    collection->reserve(20); // Reserve space for 20 elements

    ASSERT_EQ(collection->size(), prevSize); // Ensure size remains unchanged
    ASSERT_GT(collection->capacity(), prevCapacity); // Ensure capacity has increased
}

// Test that std::out_of_range exception is thrown when accessing out-of-bounds index
// NOTE: This is a negative test
TEST_F(CollectionTest, OutOfRange)
{
    std::vector<int> myvector(10); // Create a vector with 10 elements
    EXPECT_THROW(myvector.at(20), std::out_of_range); // Access out-of-bounds index
}

// Positive test: Verify that multiplying entries increases the size of the collection
TEST_F(CollectionTest, MultiplyEntries)
{
    ASSERT_TRUE(collection->empty()); // Ensure the collection is initially empty
    ASSERT_EQ(collection->size(), 0); // Ensure size is 0

    add_entries(25); // Add 25 entries to the collection

    ASSERT_FALSE(collection->empty()); // Ensure the collection is no longer empty
    ASSERT_EQ(collection->size(), 25); // Ensure the size is 25
}

// Negative test: Verify that pop_back removes one element from the collection
TEST_F(CollectionTest, PopBack)
{
    add_entries(10); // Add ten entries to the collection

    collection->pop_back(); // Remove one entry from the collection

    ASSERT_FALSE(collection->size() == 10); // Ensure size is not 10
}

